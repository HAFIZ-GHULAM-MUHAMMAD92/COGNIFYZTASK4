function changeColor(event){
	var color='yellow';
	event.style.backgroundColor=color;
}